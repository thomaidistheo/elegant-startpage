a startpage for the browser with 3 tools for quick access: a todo list, notes,  bookmarked links <br>

Available as an extension for Chrome and Firefox. <br>
Latest Version: 1.6.1 <br>

Download: <a href="https://elegant-sp.netlify.app">here</a> <br>
Direct links: <a href="https://chrome.google.com/webstore/detail/elegant-startage-new-tab/fkmdkhphahhokkbocjgdpoeikggpnfel?hl=el">Chrome - (v1.1)</a> | <a href="https://addons.mozilla.org/en-US/firefox/addon/elegant-startage-new-tab/"> Firefox - (v1.6.1)</a>

<img src="https://raw.githubusercontent.com/thomaidistheo/elegant-startpage/main/assets/screenshots/theme-screenshot.png">

<img src="https://raw.githubusercontent.com/thomaidistheo/elegant-startpage/main/assets/screenshots/dark_mode_screenshot.jpg">


<img src="https://raw.githubusercontent.com/thomaidistheo/elegant-startpage/main/assets/screenshots/light_mode_screenshot.jpg">

