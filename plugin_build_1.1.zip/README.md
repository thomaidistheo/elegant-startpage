a startpage for the browser with 3 tools for quick access: a todo list, notes,  bookmarked links

<img src="https://raw.githubusercontent.com/thomaidistheo/elegant-startpage/main/assets/screenshot_1.jpg">


<img src="https://raw.githubusercontent.com/thomaidistheo/elegant-startpage/main/assets/screenshot_2.jpg">

